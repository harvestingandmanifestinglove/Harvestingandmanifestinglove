const toast = document.getElementById("toast");

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2800);
}

document.querySelectorAll("[data-scroll]").forEach(button => {
  button.addEventListener("click", () => {
    const target = document.querySelector(button.dataset.scroll);
    if (target) target.scrollIntoView({ behavior: "smooth", block: "start" });
  });
});

document.querySelectorAll(".profile-btn").forEach(button => {
  button.addEventListener("click", () => {
    showToast(`Hello! ${button.dataset.name}'s profile is a preview. Real messaging will be available after launch.`);
  });
});

document.getElementById("joinForm").addEventListener("submit", event => {
  event.preventDefault();
  const name = document.getElementById("name").value.trim();
  showToast(`Thanks${name ? `, ${name}` : ""}! You're on the launch list preview.`);
  document.getElementById("formMessage").textContent =
    "Thanks! This demo does not store submissions yet. A secure backend will be connected before launch.";
  event.target.reset();
});
